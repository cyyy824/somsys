from ..fr_CH import Provider as BaseProvider


class Provider(BaseProvider):
    pass
