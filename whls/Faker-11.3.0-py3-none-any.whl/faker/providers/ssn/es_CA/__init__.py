from ..es_ES import Provider as BaseProvider


class Provider(BaseProvider):
    """
    A Faker provider for the Spanish VAT IDs and DOIs
    """

    pass
